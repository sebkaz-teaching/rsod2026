-- A new item no longer requires a fictional issue document.
INSERT INTO items (item_id, item_name) VALUES ('N-01', 'Namiot');
SELECT i.item_id, i.item_name, COUNT(di.document_id) AS issue_count
FROM items AS i
LEFT JOIN document_items AS di ON di.item_id = i.item_id
GROUP BY i.item_id, i.item_name ORDER BY i.item_id;
