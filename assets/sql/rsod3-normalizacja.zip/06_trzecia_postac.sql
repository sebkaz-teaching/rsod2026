-- Undo the deliberate anomaly using the known source value.
UPDATE documents_2nf SET team_name = 'Alfa' WHERE team_id = 'A';
CREATE TABLE teams (
    team_id TEXT NOT NULL PRIMARY KEY,
    team_name TEXT NOT NULL
) STRICT;
CREATE TABLE items (
    item_id TEXT NOT NULL PRIMARY KEY,
    item_name TEXT NOT NULL
) STRICT;
CREATE TABLE documents (
    document_id INTEGER PRIMARY KEY,
    issued_at TEXT NOT NULL,
    team_id TEXT NOT NULL REFERENCES teams(team_id)
) STRICT;
CREATE TABLE document_items (
    document_id INTEGER NOT NULL REFERENCES documents(document_id),
    item_id TEXT NOT NULL REFERENCES items(item_id),
    PRIMARY KEY (document_id, item_id)
) STRICT;
INSERT INTO teams SELECT DISTINCT team_id, team_name FROM documents_2nf;
INSERT INTO items SELECT item_id, item_name FROM items_2nf;
INSERT INTO documents SELECT document_id, issued_at, team_id FROM documents_2nf;
INSERT INTO document_items SELECT document_id, item_id FROM document_items_2nf;
CREATE VIEW issue_report AS
SELECT d.document_id, i.item_id, i.item_name, d.issued_at, t.team_id, t.team_name
FROM documents AS d
JOIN document_items AS di ON di.document_id = d.document_id
JOIN items AS i ON i.item_id = di.item_id
JOIN teams AS t ON t.team_id = d.team_id;
SELECT * FROM issue_report ORDER BY document_id, item_id;
