-- Compare both directions before introducing any new changes.
-- All three result sets should be empty.
SELECT * FROM issue_lines_1nf EXCEPT SELECT * FROM issue_report;
SELECT * FROM issue_report EXCEPT SELECT * FROM issue_lines_1nf;
PRAGMA foreign_key_check;
