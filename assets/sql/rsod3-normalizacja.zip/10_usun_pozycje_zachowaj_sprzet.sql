-- Delete the only issue line for R-02, not the inventory item itself.
DELETE FROM document_items WHERE document_id = 202 AND item_id = 'R-02';
SELECT i.item_id, i.item_name, COUNT(di.document_id) AS issue_count
FROM items AS i
LEFT JOIN document_items AS di ON di.item_id = i.item_id
WHERE i.item_id = 'R-02'
GROUP BY i.item_id, i.item_name;
