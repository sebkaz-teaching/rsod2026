-- Restore the known source value before decomposing the relation.
UPDATE issue_lines_1nf SET team_name = 'Alfa' WHERE team_id = 'A';
-- All checks must return no rows. Do not resolve conflicting names with MIN.
SELECT team_id FROM issue_lines_1nf
GROUP BY team_id HAVING COUNT(DISTINCT team_name) > 1;
SELECT item_id FROM issue_lines_1nf
GROUP BY item_id HAVING COUNT(DISTINCT item_name) > 1;
SELECT document_id FROM issue_lines_1nf
GROUP BY document_id
HAVING COUNT(DISTINCT team_id) > 1 OR COUNT(DISTINCT issued_at) > 1;
