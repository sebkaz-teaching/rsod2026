-- Run once after steps 08-10 to restore the initial normalized data.
INSERT INTO document_items (document_id, item_id) VALUES (202, 'R-02');
DELETE FROM items WHERE item_id = 'N-01';
UPDATE teams SET team_name = 'Alfa' WHERE team_id = 'A';
SELECT * FROM issue_report ORDER BY document_id, item_id;
