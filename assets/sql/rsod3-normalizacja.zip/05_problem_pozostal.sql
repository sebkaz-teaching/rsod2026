-- A team name is still copied across different documents.
UPDATE documents_2nf SET team_name = 'Alfa Polnoc' WHERE document_id = 201;
SELECT document_id, team_id, team_name FROM documents_2nf
WHERE team_id = 'A' ORDER BY document_id;
