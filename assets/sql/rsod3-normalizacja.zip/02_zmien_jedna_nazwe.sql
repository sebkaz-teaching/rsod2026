-- Intentional anomaly: update only one copy of a current team name.
UPDATE issue_lines_1nf SET team_name = 'Alfa Polnoc'
WHERE document_id = 201 AND item_id = 'R-01';
SELECT document_id, item_id, team_id, team_name
FROM issue_lines_1nf WHERE team_id = 'A'
ORDER BY document_id, item_id;
