CREATE TABLE issue_lines_1nf (
    document_id INTEGER NOT NULL,
    item_id TEXT NOT NULL,
    item_name TEXT NOT NULL,
    issued_at TEXT NOT NULL,
    team_id TEXT NOT NULL,
    team_name TEXT NOT NULL,
    PRIMARY KEY (document_id, item_id)
) STRICT;

-- Explicitly transcribe all six values for each document line.
INSERT INTO issue_lines_1nf (
    document_id, item_id, item_name, issued_at, team_id, team_name
)
VALUES
    (201, 'R-01', 'Radiostacja',          '2027-02-01 08:00', 'A', 'Alfa'),
    (201, 'L-01', 'Latarka',             '2027-02-01 08:00', 'A', 'Alfa'),
    (202, 'R-02', 'Radiostacja zapasowa', '2027-02-02 09:00', 'B', 'Bravo'),
    (203, 'R-01', 'Radiostacja',          '2027-02-03 10:00', 'A', 'Alfa');

SELECT * FROM issue_lines_1nf ORDER BY document_id, item_id;
