UPDATE teams SET team_name = 'Alfa Polnoc' WHERE team_id = 'A';
SELECT * FROM issue_report WHERE team_id = 'A' ORDER BY document_id, item_id;
