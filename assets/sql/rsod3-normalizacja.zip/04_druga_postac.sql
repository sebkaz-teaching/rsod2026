CREATE TABLE items_2nf (
    item_id TEXT NOT NULL PRIMARY KEY,
    item_name TEXT NOT NULL
) STRICT;
CREATE TABLE documents_2nf (
    document_id INTEGER PRIMARY KEY,
    issued_at TEXT NOT NULL,
    team_id TEXT NOT NULL,
    team_name TEXT NOT NULL
) STRICT;
CREATE TABLE document_items_2nf (
    document_id INTEGER NOT NULL REFERENCES documents_2nf(document_id),
    item_id TEXT NOT NULL REFERENCES items_2nf(item_id),
    PRIMARY KEY (document_id, item_id)
) STRICT;
INSERT INTO items_2nf SELECT DISTINCT item_id, item_name FROM issue_lines_1nf;
INSERT INTO documents_2nf
SELECT DISTINCT document_id, issued_at, team_id, team_name FROM issue_lines_1nf;
INSERT INTO document_items_2nf SELECT document_id, item_id FROM issue_lines_1nf;
SELECT * FROM documents_2nf ORDER BY document_id;
