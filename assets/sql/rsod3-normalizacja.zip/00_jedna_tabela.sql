-- Run once in a new, empty database. Requires SQLite 3.37+.
PRAGMA foreign_keys = ON;
PRAGMA foreign_keys;
CREATE TABLE raw_issues (
    document_id INTEGER PRIMARY KEY,
    issued_at TEXT NOT NULL,
    team_id TEXT NOT NULL,
    team_name TEXT NOT NULL,
    equipment_list TEXT NOT NULL
) STRICT;
INSERT INTO raw_issues VALUES
    (201, '2027-02-01 08:00', 'A', 'Alfa', 'R-01: Radiostacja; L-01: Latarka'),
    (202, '2027-02-02 09:00', 'B', 'Bravo', 'R-02: Radiostacja zapasowa'),
    (203, '2027-02-03 10:00', 'A', 'Alfa', 'R-01: Radiostacja');
SELECT * FROM raw_issues ORDER BY document_id;
