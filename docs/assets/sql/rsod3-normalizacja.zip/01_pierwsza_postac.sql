CREATE TABLE issue_lines_1nf (
    document_id INTEGER NOT NULL,
    item_id TEXT NOT NULL,
    item_name TEXT NOT NULL,
    issued_at TEXT NOT NULL,
    team_id TEXT NOT NULL,
    team_name TEXT NOT NULL,
    PRIMARY KEY (document_id, item_id)
) STRICT;
-- Manually transcribe the equipment lists from the three source documents.
-- This explicit mapping is for this example, not a general text parser.
WITH expanded(document_id, item_id, item_name) AS (
    VALUES (201, 'R-01', 'Radiostacja'),
           (201, 'L-01', 'Latarka'),
           (202, 'R-02', 'Radiostacja zapasowa'),
           (203, 'R-01', 'Radiostacja')
)
INSERT INTO issue_lines_1nf
SELECT r.document_id, e.item_id, e.item_name,
       r.issued_at, r.team_id, r.team_name
FROM raw_issues AS r
JOIN expanded AS e ON e.document_id = r.document_id;
SELECT * FROM issue_lines_1nf ORDER BY document_id, item_id;
